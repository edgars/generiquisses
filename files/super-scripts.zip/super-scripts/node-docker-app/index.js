const express = require('express');
const { spawn } = require("child_process");
const { Docker } = require("node-docker-api");
const docker = new Docker({ socketPath: "/var/run/docker.sock" });

const ls = spawn("ls", ["-la"]);

let container;

const app = express();

app.get('/ping', (req, res) => {
  res.send('pong');
});


app.get('/docker', (req, res) => {
// List
docker.container.list()
   // Inspect
  .then((containers) => containers[0].status())
  .then((container) => container.stats())
  .then((stats) => {
    stats.on('data', (stat) => res.send(`stdout: ${stat}`))
    stats.on('error', (err) => console.log('Error: ', err))
  })
  .catch((error) => console.log(error))

  //res.send(`stdout: ${stat}`);
    
  });


app.get('/ls', (req, res) => {

    ls.stdout.on("data", data => {
        console.log(`stdout: ${data}`);
        res.send(`stdout: ${data}`);
    });
    
  });
  

app.listen(3002, () => {
  console.log('listening on port 3002');
});